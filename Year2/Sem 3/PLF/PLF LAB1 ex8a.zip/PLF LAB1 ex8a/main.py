# This is a sample Python script.

# Press ⌃R to execute it or replace it with your code.
# Press Double ⇧ to search everywhere for classes, files, tool windows, actions, and settings.


class Nod:
    def __init__(self, e):
        self.e = e
        self.urm = None


class Lista:
    def __init__(self):
        self.prim = None


'''
crearea unei liste din valori citite pana la 0
'''
def creareLista():
    lista = Lista()
    lista.prim = creareLista_rec()
    return lista


def creareLista_rec():
    x = int(input("x="))
    if x == 0:
        return None
    else:
        nod = Nod(x)
        nod.urm = creareLista_rec()
        return nod


'''
tiparirea elementelor unei liste
'''


def tipar(lista):
    tipar_rec(lista.prim)


def tipar_rec(nod):
    if nod != None:
        print(nod.e)
        tipar_rec(nod.urm)



'''
8a)
'''

def lcm(a,b,i):
    if (a==0 or b==0):
        return 0
    if (i%a == 0 and i%b==0):
        return i
    return lcm(a,b,i+1)

def f(lista):
    nod = lista.prim
    if (nod != None):
        if (nod.urm!= None):
            lista2 = Lista()
            lista2.prim = lista.prim.urm
            lista2.prim.e = lcm(lista.prim.e, lista.prim.urm.e, 1)
            return f(lista2)
        else:
            return nod.e
    else:
        return 0


'''
8b)
'''

def f2(lista, e, e1):
    if (lista.prim == None):
        return lista
    if (lista.prim.e == e):
        lista2 = Lista()
        lista2.prim = lista.prim.urm
        f2(lista2, e, e1)
        lista.prim.e = e1
    else:
        lista2 = Lista()
        lista2.prim = lista.prim.urm
        f2(lista2, e, e1)
    return lista

'''
program pentru test
'''


def main():
    print("EX 8B")
    list = creareLista()
    tipar(list)
    e = int(input("e="))
    e1 = int(input("e1="))
    print("NEW LIST")
    lista2 = f2(list, e, e1)
    tipar(lista2)
    print("EX 8A")
    list2 = creareLista()
    x = f(list2)
    print("RESULT")
    print(x)



main()

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
